<p align="right">
  <img src="https://visitor-badge.laobi.icu/badge?page_id=kad-f.kad-f" />
</p>

<p align="center">
  <img src="https://user-images.githubusercontent.com/74038190/240906093-9be4d344-6782-461a-b5a6-32a07bf7b34e.gif">
</p>

<div align="center">
  <h2>Aspiring Software Engineer</h2>
  <p>
   🚀 I am currently a third-year college student majoring in <strong>Bachelor Of Science In Information Technology</strong>
  </p>
</div>

<div align="center">
  <p>🌱 I’m currently learning <strong>MERN Stack</strong></p>
  <p>💬 Ask me about <strong>Javascript, C, C++, PHP... or anything <a href="https://github.com/kad-f">here</a></strong></p>
</div>

<div align="center">
  <a href="mailto:keyanandydelgado@gmail.com">
    <img src="https://img.shields.io/badge/Gmail-333333?style=for-the-badge&logo=gmail&logoColor=red" />
  </a>
  <a href="https://www.facebook.com/keyandelgado.fajanoy">
    <img alt="Facebook" title="Connect on Facebook" src="https://img.shields.io/badge/-Facebook-1877F2?style=for-the-badge&logo=facebook&logoColor=white"/>
  </a>
  <a href="https://www.instagram.com/https.keyan/">
    <img alt="Instagram" title "Follow on Instagram" src="https://img.shields.io/badge/-Instagram-E4405F?style=for-the-badge&logo=instagram&logoColor=white"/>
  </a>
</div>

<hr/>

<h2 align="center">⚒️ Languages-Frameworks-Tools ⚒️</h2>

<div align="center">
  <img src="https://skillicons.dev/icons?i=nodejs,github,c,javascript,typescript,express,mongodb,java" /><br>
  <img src="https://skillicons.dev/icons?i=react,bootstrap,mui,mysql,flask,html,css,vscode,figma,git" />
</div>

<hr/>

<h2 align="center">⚡ Stats ⚡</h2>

<div align="center">
  <img width=390 src="https://streak-stats.demolab.com/?user=kad-f&count_private=true&theme=react&border_radius=10" alt="streak stats"/>
  <img width=390 src="https://github-readme-stats.vercel.app/api?username=kad-f&count_private=true&show_icons=true&theme=react&rank_icon=github&border_radius=10" alt="readme stats" />
  <br/>
  <img width=325 align="center" src="https://github-readme-stats.vercel.app/api/top-langs/?username=kad-f&hide=HTML&langs_count=8&layout=compact&theme=react&border_radius=10&size_weight=0.5&count_weight=0.5&exclude_repo=github-readme-stats" alt="top langs" />
</div>

<hr/>

<h3 align="center">
  <img src="https://readme-typing-svg.herokuapp.com/?font=Righteous&size=25&center=true&vCenter=true&width=500&height=70&duration=4000&lines=Thanks+for+visiting!+✌️;+Shoot+me+a+message+on+Facebook!;I'm+always+down+to+collab+:)">
</h3>
