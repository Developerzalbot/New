<img width=100% src="https://capsule-render.vercel.app/api?type=waving&color=7B68EE&height=120&section=header"/>

# Olá👋, Bem-vindo ao meu perfil do GitHub

<img src="https://readme-typing-svg.herokuapp.com?font=Architects+Daughter&color=A020F0&size=27&center=false&lines=Meu+Nome+é+Marcia+Gabrielle...;Tenho+21+anos+...;Estudante+de+Ciência+da+Computação..."/>

 <p>- <i>Estudante de Ciência da Computação apaixonada por tecnologia e inovação. Desenvolvendo habilidades em programação, algoritmos e análise de dados. Interessado em inteligência artificial, aprendizado de máquina e Ciência de Dados. Comprometida com a aprendizagem contínua e em busca de oportunidades para aplicar meu conhecimento e contribuir para soluções tecnológicas inovadoras.</i></p>

<img src="https://media.tenor.com/pPoUmi0Z1fUAAAAC/cat-pet.gif" width="45%" align="right" />

## ⚡🙋‍♂️ Sobre mim

</br>

- 🌱 Estudando Ciência de Dados com Python
- 😄 Pronouns: ela/dela
- 📫 Como chegar até mim: gabybonifacio2@gmail.com

<hr>

<!-- [![Ashutosh's github activity graph](https://github-readme-activity-graph.cyclic.app/graph?username=MarciaGabrielle&bg_color=0d1117&color=7B68EE&line=7B68EE&point=ff9494&area=true&hide_border=true)](https://github.com/ashutosh00710/github-readme-activity-graph) -->
<p align="center">
  <img src="https://github-profile-trophy.vercel.app/?username=MarciaGabrielle&theme=dracula&row=2&no-bg=true&column=3&margin-w=15&margin-h=15" />
</p>
<div>
<div align="center">  
  <img width="49%" height="160px" src="https://github-readme-stats.vercel.app/api?username=MarciaGabrielle&show_icons=true&count_private=true&hide_border=true&title_color=9932CC&icon_color=9932CC&text_color=c9d1d9&bg_color=0d1117" alt="Marcia Gabrielle github stats" /> 
  <img width="41%" height="160px" src="https://github-readme-stats.vercel.app/api/top-langs/?username=MarciaGabrielle&layout=compact&hide_border=true&title_color=9932CC&text_color=EE82EE&bg_color=0d1117" />
</div>
<div>

<div align="center"> 
<a href="https://www.instagram.com/marcy_bonifacio/" target="_blank"><img src="https://img.shields.io/badge/-Instagram-%23E4405F?style=for-the-badge&logo=instagram&logoColor=white"</a>
<a href = "mailto:cmp.1a.gabybonifacio2@gmail.com"> <img src="https://img.shields.io/badge/-Gmail-%23333?style=for-the-badge&logo=gmail&logoColor=white" target="_blank"></a>
<a href="https://www.linkedin.com/in/marcia-oliveira-956994205/" target="_blank"><img src="https://img.shields.io/badge/-LinkedIn-%230077B5?style=for-the-badge&logo=linkedin&logoColor=white" style="border-radius: 30px" target="_blank"></a> 
 </div>
 
### Main skills:


### Studying in this moment:

<p align="center">
  <img  src="https://raw.githubusercontent.com/MarciaGabrielle/MarciaGabrielle/main/resources/img/github-contribution-grid-snake.svg"
    alt="example" />
</p>

<div align="center">
<br><p align="centre"><b>Visitors Count</b></p>  

<p align="center"><img align="center" src="https://profile-counter.glitch.me/{MarciaGabrielle}/count.svg" /></p> 
<br>
</div>

 ------
 Credit: [MarciaGabrielle](https://github.com/MarciaGabrielle)
 Last Edited on: 24/08/2023
 
<img width=100% src="https://capsule-render.vercel.app/api?type=waving&color=7B68EE&height=120&section=footer"/>
