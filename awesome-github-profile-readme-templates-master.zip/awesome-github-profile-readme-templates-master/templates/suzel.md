# Sukru Uzel

[![LinkedIn](https://img.shields.io/badge/LinkedIn-blue?style=flat&logo=linkedin&labelColor=blue)](https://www.linkedin.com/in/sukru-uzel)

I'm Sukru. Software developer working with Headless APIs, JavaScript, Svelte, and GraphQL.

## Get in touch
- Personal Website: [sukruuzel.com](https://www.sukruuzel.com)
- LinkedIn: https://www.linkedin.com/in/sukru-uzel
-----
Credits: [suzel](https://github.com/suzel)

Last Edited on: 19/11/2020