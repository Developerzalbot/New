# Konichiwa 👋

<div align="center">
<img hight="300" width="700" alt="GIF" align="center" src="https://github.com/Xx-Ashutosh-xX/Xx-Ashutosh-xX/blob/master/assets/208593.gif">
</div>

</br>
</br>
</br>


# About ME 💬 :

### - I'm 18 years  old Machine Learning & Artificial Intelligence Enthusiast from India.

<img hight="400" width="500" alt="GIF" align="right" src="https://github.com/Xx-Ashutosh-xX/Xx-Ashutosh-xX/blob/master/assets/1936.gif">

### - Learning :
- ✨ Tensorflow
- ✨ Neural Style Transfer
- ✨ Julia

### - Hobbies : 
- ✨ Gaming
- ✨ Watching Anime
- ✨ Reading Light Novels
- ✨ Badminton (Neighbourhood Professional XD)

</br>
</br>
</br>



# Languages & Tools 👨‍💻 🛠:
</br>

<p align="center">

<!-- For more icons please follow  https://github.com/MikeCodesDotNET/ColoredBadges -->
<img src="https://github.com/Xx-Ashutosh-xX/Xx-Ashutosh-xX/blob/master/assets/icons/python.png" alt="python" width="120" hight="50">
<img src="https://github.com/Xx-Ashutosh-xX/Xx-Ashutosh-xX/blob/master/assets/icons/java.png" alt="java"  width="100" hight="50">
<img src="https://github.com/Xx-Ashutosh-xX/Xx-Ashutosh-xX/blob/master/assets/icons/ai.png" alt="AI" width="90" hight="50">
<img src="https://github.com/Xx-Ashutosh-xX/Xx-Ashutosh-xX/blob/master/assets/icons/bash.png" alt="bash" width="100" hight="50">
<img src="https://github.com/Xx-Ashutosh-xX/Xx-Ashutosh-xX/blob/master/assets/icons/datascience.png" alt="datascience" width="180" hight="50">
</br>
<img src="https://github.com/Xx-Ashutosh-xX/Xx-Ashutosh-xX/blob/master/assets/icons/google_cloud_platform.png" alt="google_cloud_platform" width="270" hight="50">
<img src="https://github.com/Xx-Ashutosh-xX/Xx-Ashutosh-xX/blob/master/assets/icons/visualstudio_code.png" alt="visualstudio_code" width="240" hight="50">
</br>
<img src="https://github.com/Xx-Ashutosh-xX/Xx-Ashutosh-xX/blob/master/assets/icons/pc.png" alt="pc" width="100" hight="50">
<img src="https://github.com/Xx-Ashutosh-xX/Xx-Ashutosh-xX/blob/master/assets/icons/edge.png" alt="edge" width="100" hight="50">
<img src="https://github.com/Xx-Ashutosh-xX/Xx-Ashutosh-xX/blob/master/assets/icons/playstation@3x.png" alt="playstation" width="150" hight="50">
</p>
</br>
</br>
</br>



# Contact Me :

<p>
 </br>


<img hight="320" width="450" align="right" alt="GIF" src="https://github.com/Xx-Ashutosh-xX/Xx-Ashutosh-xX/blob/master/assets/93195.gif">


If you want to reach out to me about anything, be it some doubt or just to hangout and talk or want to game together just ping me 😉.

<a href="mailto:ashutosh.saxena.2001@gmail.com">
 <img align="left" alt="Gmail" width="130" hight="100" src="https://github.com/Xx-Ashutosh-xX/Xx-Ashutosh-xX/blob/master/assets/icons/gmail.png" />
</a>
<a href="https://www.linkedin.com/in/ashutosh-saxena-7b326817b/">
  <img align="left" alt="Linkedin" width="150" hight="100" src="https://github.com/Xx-Ashutosh-xX/Xx-Ashutosh-xX/blob/master/assets/icons/linkedin.png" />
</br>
</br>
</br>
</a>
<a href="https://www.reddit.com/user/X_Ashutosh_X">
  <img align="left" alt=" Reddit" width="130" hight="100" src="https://github.com/Xx-Ashutosh-xX/Xx-Ashutosh-xX/blob/master/assets/icons/reddit.png" />
</a>
<a href="https://steamcommunity.com/profiles/76561198182224539/">
  <img align="left" alt="Steam" width="130" hight="100" src="https://github.com/Xx-Ashutosh-xX/Xx-Ashutosh-xX/blob/master/assets/icons/steam.png" />
</a>
 </p>
 

</br>
</br>
</br>
</br>
</br>
</br>
</br>



<p align="center" >  
  <a href="https://github.com/anuraghazra/github-readme-stats"> 
<img  src="https://github-readme-stats.vercel.app/api?username=Xx-Ashutosh-xX&&show_icons=true&theme=radical"/>
  </a>
  </p>

-----
Credits: [Xx-Ashutosh-xX](https://github.com/Xx-Ashutosh-xX)

Last Edited on: 30/08/2020