### Hello, nerds 👋

<p align="center">
  <img src="https://user-images.githubusercontent.com/5679180/79618120-0daffb80-80be-11ea-819e-d2b0fa904d07.gif" width="27px">
  <br><br>
  <samp>
I'm Naiyarah. A Web Developer from Sri Lanka and Developer Advocate at IBM focusing on Data & AI. I work with developers from enterprises, startups, open source communities & universities to build their apps & solutions.
     <br><br>Contact me on <a href="https://twitter.com/naisofly">Twitter</a>, <a href="https://www.linkedin.com/in/naiyarah/">Linkedin</a>, or <a href="mailto:naiyarah.h@gmail.com">Send an Email</a>
  </samp>
</p>

<!--
**naisofly/naisofly** is a ✨ _special_ ✨ repository because its `README.md` (this file) appears on your GitHub profile.

Here are some ideas to get you started:

- 🔭 I’m currently working on ...
- 🌱 I’m currently learning ...
- 👯 I’m looking to collaborate on ...
- 🤔 I’m looking for help with ...
- 💬 Ask me about ...
- 📫 How to reach me: ...
- 😄 Pronouns: ...
- ⚡ Fun fact: ...
-->

-----
Credits: [Naiyarah Hussain](https://github.com/naisofly)

Last Edited on: 30/11/2020