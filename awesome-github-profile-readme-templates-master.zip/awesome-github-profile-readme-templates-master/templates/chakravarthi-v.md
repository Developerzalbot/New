<h1 align="center">Hi, I'm Chakravarthi <img src="https://media.giphy.com/media/hvRJCLFzcasrR4ia7z/giphy.gif" width="25px"></h1>

<p align="center">
  <a href="https://www.linkedin.com/in/chakravarthi-v/">
   <img src="https://img.icons8.com/color/48/000000/linkedin.png" width="3.5%"/>
    </a><span>&nbsp;</span>
  <a href="https://twitter.com/ChakriVV">
    <img src="https://img.icons8.com/color/48/000000/twitter.png" width="3.5%"/>
  </a><span>&nbsp;</span>
  <a href="https://www.instagram.com/___chakri_/">
    <img src="https://img.icons8.com/fluent/48/000000/instagram-new.png" width="3.5%"/>
  </a><span>&nbsp;</span>
  <a href="mailto:chakravarthiviswanath@gmail.com">
    <img src="https://img.icons8.com/fluent/48/000000/gmail.png" width="3.5%"/>
  </a><span>&nbsp;</span>
  <a href="https://github.com/chakravarthi-v">
    <img src="https://img.icons8.com/fluent/48/000000/github.png" width="3.5%"/>
  </a><span>&nbsp;</span>
</p>
<h3 align="center">A Junior Computer Science Undergrad at SRM Institute of Science and Technology who is currently learning MERN stack web development</h3>

<br>

<br>

  <a href="https://github.com/chakravarthi-v">
    <img align="center" src="https://github-readme-stats.vercel.app/api/top-langs/?username=chakravarthi-v&hide=ASP.NET,jupyter%20notebook&theme=dark&hide_langs_below=1" height="220px"/>
  </a>
  <a href="https://github.com/chakravarthi-v">
   <img align="center" src="https://github-readme-stats.vercel.app/api?username=chakravarthi-v&count_private=true&hide=stars&show_icons=true&theme=dark&line_height=27" alt="Chakravarthi's github stats" height="220px" />
  </a>



![visitors](https://visitor-badge.laobi.icu/badge?page_id=chakravarthi-v.408179647)

------

Credit: [chakravarthi-v](https://github.com/chakravarthi-v)

Last Edited on: 20/09/2021
