hello! here's a little about me:

<h1>
  i really like music :headphones:
</h1>

<!-- Nothing weird to see here -->
<p align="center">
  <a href="https://andyruwruw.vercel.app/api/now-playing?open">
    <!-- Music bars move to the beat and are colored based on the track's happiness, danceability and energy! -->
    <img src="https://andyruwruw.vercel.app/api/now-playing">
  </a>
</p>

<p align="center">
  <img src="https://andyruwruw.vercel.app/api/top-played">
</p>
 
<p align="center">
  <!-- He came up with the idea of HOW to show React components as an img on a README.md and the now playing component! -->
  <i>inspired by <a href="https://github.com/natemoo-re">natemoo-re</a></i>
</p>

<p></p>

<h1>
  i was a frontend intern at chess.com ♟️
</h1>

<p align="center">
  <a href="https://www.chess.com/member/andyruwruw">
    <img src="https://andyruwruw.vercel.app/api/chess-games">
  </a>
</p>

<p align="center">
  <i>luckily being good at chess wasn't a pre-req to the job</i>
</p>

<p></p>

<h1>
  i'm a vue.js fanboy, but i do some other stuff too :hammer:
</h1>

<p align="center">
  <img src="https://andyruwruw.vercel.app/api/skills">
</p>

-----
Credits: [andyruwruw](https://github.com/andyruwruw)

Last Edited on: 08/01/2021