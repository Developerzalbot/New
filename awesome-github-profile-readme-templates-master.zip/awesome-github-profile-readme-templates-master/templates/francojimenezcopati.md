<img id='gif' align="right" src="https://media.giphy.com/media/CrFLL3CnRpw5ddlBMm/giphy.gif" width="240">
<header align="left">
    <h1 align="left">Hi everyone <img src="https://media.giphy.com/media/hvRJCLFzcasrR4ia7z/giphy.gif" width="35"></h1>
    <h3 align="left">
        <ul>
            <li>🔭 I'm currently figuring out what to specialize in</li>
            <li>👨‍🎓 I'm learning Django at the moment</li>
            <li>💬 Ask me about anything you want</li>
            <li>📫 How to reach me: fjcopati@gmail.com</li>
            <li>💼 I had a 4-month internship at the company GIRE S.A.</li>
        </ul>
    </h3>
</header>
<hr>
<div align="center">
    <h2 align="center">Used Technologies</h2>
    <div align="center">
        <img src="https://github.com/devicons/devicon/blob/master/icons/c/c-original.svg" alt="C" width="80">
        <img src="https://github.com/devicons/devicon/blob/master/icons/csharp/csharp-original.svg" alt="C#" width="80">
        <img src="https://github.com/devicons/devicon/blob/master/icons/java/java-original.svg" alt="Java" width="80">
        <img src="https://github.com/devicons/devicon/blob/master/icons/html5/html5-original.svg" alt="HTML" width="80">
        <img src="https://github.com/devicons/devicon/blob/master/icons/css3/css3-original.svg" alt="CSS" width="80">
        <img src="https://github.com/devicons/devicon/blob/master/icons/javascript/javascript-original.svg" alt="JavaScript" width="80">
        <img src="https://github.com/devicons/devicon/blob/master/icons/react/react-original.svg" alt="React" width="80">
        <img src="https://github.com/devicons/devicon/blob/master/icons/python/python-original.svg" alt="Python" width="80">
    </div>
    <h2 align="center">Used IDE's</h2>
    <div align="center">
        <img src="https://github.com/devicons/devicon/blob/master/icons/intellij/intellij-original.svg" alt="Intellij" width="80">
        <img src="https://github.com/devicons/devicon/blob/master/icons/vscode/vscode-original.svg" alt="VsCode" width="80">
    </div>
</div>
<hr>
<footer align="center">
    <p align="center">
        <img src="https://github-readme-stats.vercel.app/api?username=francojimenezcopati&include_all_commits=true&show_icons=true&theme=radical" height="250">
        <img src="https://github-readme-stats.vercel.app/api/top-langs/?username=francojimenezcopati&layout=compact&hide=css&theme=radical" alt="Intellij" height="250">
    </p>
</footer>

------

Credit: [francojimenezcopati](https://github.com/francojimenezcopati)
Last Edited on: 10/01/2024