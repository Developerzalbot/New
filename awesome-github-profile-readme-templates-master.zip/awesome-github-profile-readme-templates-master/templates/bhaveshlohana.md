![](https://github.com/bhaveshlohana/bhaveshlohana/raw/master/animated-name.gif)

Hello there, I'm Bhavesh Lohana! I am currently completing my Bachelors in Computer Science. And when I am not working, you'll find me reading a sci-fi novel.

## Currently I'm:

- Working on several AI/ML projects
- Competitve Programming in JS, Python and C++
- Starting UI/UX
- Learning App Development


## Languages I use:

![C](https://img.shields.io/badge/-C-000000?style=flat&logo=C)
![JavaScript](https://img.shields.io/badge/-JavaScript-000000?style=flat&logo=javascript)
![HTML5](https://img.shields.io/badge/-HTML5-000000?style=flat&logo=HTML5)
![Java](https://img.shields.io/badge/-Java-000000?style=flat&logo=Java&logoColor=007396)
![Python](https://img.shields.io/badge/-Python-000000?style=flat&logo=python)
![SQL](https://img.shields.io/badge/-SQL-000000?style=flat&logo=MySQL)
![C++](https://img.shields.io/badge/-C++-000000?style=flat&logo=C%2B%2B&logoColor=00599C)

## Technologies I know:

![Git](https://img.shields.io/badge/-Git-000000?style=flat&logo=git&logoColor=F05032)
![jQuery](https://img.shields.io/badge/-jQuery-000000?style=flat&logo=jQuery&logoColor=0769AD)
![Node.js](https://img.shields.io/badge/-Node.js-000000?style=flat&logo=node.js&logoColor=339933)
![React](https://img.shields.io/badge/-React-000000?style=flat&logo=React&logoColor=61DAFB)
![Electron](https://img.shields.io/badge/-Electron-000000?style=flat&logo=Electron&logoColor=FFFFFF)



<img align="" height='130px' src="https://github-readme-stats.vercel.app/api?username=bhaveshlohana&hide_title=true&show_icons=true&include_all_commits=true&line_height=21&bg_color=0,EC6C6C,FFD479,FFFC79,73FA79&theme=graywhite" /><img align="" height='130px' src="https://github-readme-stats.vercel.app/api/top-langs/?username=bhaveshlohana&hide_title=true&layout=compact&bg_color=0,73FA79,73FDFF,D783FF&theme=graywhite" />

----
Credit: [bhaveshlohana](https://github.com/bhaveshlohana)

Last Edited on: 23/09/2020