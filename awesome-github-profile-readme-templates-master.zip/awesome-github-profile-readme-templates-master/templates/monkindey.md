```css
#monkindey { 
  position: Hángzhōu; 
  height: 170cm; 
  display: boy; 
  background: Tinker Resolver 🔨; 
  color: yellow 
}
```

-----
Credits: [monkindey](https://github.com/monkindey)

Last Edited on: 30/08/2020