<!-- Intro -->

<a href="https://mahiiverse-portfolio.000webhostapp.com/" target="_blank"><img src="https://github.com/mahiiverse1/mahiiverse1/blob/main/mahii-header.png" /></a>
<h1 align="center">Hi <img src="https://raw.githubusercontent.com/MartinHeinz/MartinHeinz/master/wave.gif" width="30px"> !! I'm Mahii.</h1>
<h3 align="center">About Me :</h3>  
 <p>
 👩‍🎓  A Sophomore year CSE undergrad at Terna Engineering College.
<br>🐱 I'm 19 y/o, go by she/her pronouns.
<br>💫 I’m a front-end web developer, currently learning React, Python and ML/AI.
<br>⭐ Besides all that I love reading books, sometimes writing them(lol), cats, BTS & all things aesthetic.
<br>👩‍💻 Constantly learning. I'm very interested in Open Source!
 <br> <p align="center"><i>✨(Click on the header to know more!)✨</i></p>
 </p>

<!-- Socials --> 

<h3 align="center">Let's Connect! :</h3>  
<div align="center">
<a href="https://www.linkedin.com/in/mahii-variar-9865711b3/" target="blank"><img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/linkedin/linkedin-original.svg" style="height: 3rem"/></a>

<a href="https://codepen.io/mahiiverse" target="blank">
<img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/codepen/codepen-plain.svg" style="height: 3rem; background-color:white"/>
</a>

<a href="mailto:mahiivariar26@gmail.com" target="blank">
<img src="https://github.com/mahiiverse1/mahiiverse1/blob/main/Gmail_Logo_256px.png" style="height: 3rem"/>
</a>

</div>

<!-- Tech Stack --> 

<h3 align="Center">Languages and Tools:</h3>  
<p align="center">
<img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/html5/html5-original-wordmark.svg" style="height: 4rem"/>
<img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/css3/css3-original-wordmark.svg" style="height: 4rem"/>
<img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/javascript/javascript-plain.svg" style="height: 4rem"/>
<img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/bootstrap/bootstrap-plain-wordmark.svg"  style="height: 4rem"/>
<img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/react/react-original.svg" style="height: 4rem"/>
<img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/git/git-plain.svg" style="height: 4rem"/>
<img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/github/github-original-wordmark.svg" style="height: 4rem; background-color:white"/>
<img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/python/python-original.svg"  style="height: 4rem"/>
<img src="https://github.com/devicons/devicon/blob/master/icons/java/java-original-wordmark.svg" style="height: 4rem" />
<img src="https://github.com/devicons/devicon/blob/master/icons/canva/canva-original.svg" style="height: 4rem" />
<img src="https://github.com/devicons/devicon/blob/master/icons/figma/figma-original.svg" style="height: 4rem" />
<img src="https://github.com/devicons/devicon/blob/master/icons/jetbrains/jetbrains-original.svg" style="height: 4rem" />
</p>


<!-- Visitor count -->
<div align="center">
<h3 align="center">Visitor Count: </h3> 

![Visitor Count](https://profile-counter.glitch.me/mahiiverse1/count.svg)

 </div>

<!-- Catto gifs -->

<h2 align="center">Cheers if you've read till here. So here's a cute catto 🐱 for you:</h2>

<div align="center">
    <img src="https://github.com/mahiiverse1/mahiiverse1/blob/main/bongo-cat.gif" width="500" height="300"/>
      
</div>
