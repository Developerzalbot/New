<h1 align="center"> Hi there 👋 </h1>
<p align="center"> I am aayushi Sharma. I Love ❤️ programming and currently working as Machine learning engineer. </p>
<img align="right" src="https://www.kindpng.com/picc/m/274-2748314_freetoedit-menherachan-animegirl-animecute-png-kawaii-anime-girl.png" height="300" width="300">
<h3 align="center"> Language & Skills </h3>

- Python
- C++
- JavaScipt
- Web Development
- Machine Learning
- Deep learning
- Natural language processing
- App Development

<h4 align="center">Things got bugs, gonna smash them one by one</h4>

<img align="center" src="https://github-readme-stats.vercel.app/api?username=aayushi-droid&show_icons=true&include_all_commits=true&theme=blue-white&count_private=true" alt="github stats">

[![trophy](https://github-profile-trophy.vercel.app/?username=aayushi-droid&theme=gruvbox)](https://github.com/ryo-ma/github-profile-trophy)
- 📝 I regulary write articles on [Aayushi's Blog](http://aayushi-droid.github.io/)

<p align="center">
<a href="https://dev.to/aayushidroid" target="blank"><img align="center" src="https://cdn.jsdelivr.net/npm/simple-icons@3.0.1/icons/dev-dot-to.svg" alt="aayushi-droid" height="40" width="40" /></a>
</p>

-----
Credits: [aayushi-droid](https://github.com/aayushi-droid)

Last Edited on: 27/12/2020