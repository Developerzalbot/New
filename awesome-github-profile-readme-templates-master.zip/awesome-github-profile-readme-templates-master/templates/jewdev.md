<img align="left" height="200" src="https://media.giphy.com/media/ao9DUiTKH60XS/giphy.gif"/>

```diff
hi, im jd 🔮.

@@advanced programming student.@@
+ living in tel aviv, israel.
- 17 years old
! program engineer, web developer and shitposter
# 📖 reverse engineering, computer science
```
------
[jewdev](https://github.com/jewdev)
Last Edited on: 03/09/2021