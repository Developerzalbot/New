<h2 title="hehehe"> Hey 👋, I'm Sanskar!</h2>

<a href="https://www.linkedin.com/in/sanskar-jaiswal-102b661a3/">
  <img align="left" alt="Sanskar's LinkedIn" width="24px" src="https://img.icons8.com/nolan/96/linkedin.png" />
</a>
<a href="https://www.instagram.com/j.sanskarr/">
  <img align="left" alt="Sanskar's Instagram" width="24px" src="https://img.icons8.com/nolan/96/instagram-new.png" />
</a>
<a href="https://twitter.com/TitanWithKagune">
  <img align="left" alt="Sanskar's Twitter" width="24px" src="https://img.icons8.com/nolan/96/twitter.png" />
</a>




<br />
<br />


 

  <img align="right" alt="GIF" src="https://media.giphy.com/media/LmNwrBhejkK9EFP504/giphy.gif" />

**About Me!**

- 👨🏽‍💻 I’m currently a ISE Undergrad student at RNS Institute of Technology, Bangalore
- 🌱 I’m currently exploring Blockchain with a big interest in Smart Contracts. 
- 💬 Ask me about anything, I love to answer!
- 📫 Email me at [phoenix2810@protonmail.com](mailto:phoenix2810@protonmail.com).



**Languages and Tools:**  


<code><img height="20" src="https://img.icons8.com/nolan/96/python.png"></code> Python
<code><img height="20" src="https://img.icons8.com/nolan/96/ethereum.png"></code> Solidity

<code><img height="20" src="https://img.icons8.com/nolan/96/c-plus-plus.png"></code> C++
<code><img height="20" src="https://img.icons8.com/nolan/96/sql.png"></code> MySQL

<code><img height="20" src="https://img.icons8.com/nolan/96/git.png"></code> GIT

<img src="https://github-readme-stats.vercel.app/api?username=sanskarjaiswal2001&show_icons=true&hide_border=true&count_private=true&theme=shades-of-purple&icon_color=fad000" alt="Sanskar's GitHub Stats">
<img align="center" src="https://github-readme-streak-stats.herokuapp.com/?user=sanskarjaiswal2001&count_private=true&theme=radical" alt="SanskarJaiswal" />
<img align="center" width=500 src="https://github-readme-stats.vercel.app/api/top-langs/?username=sanskarjaiswal2001&count_private=true&theme=radical" alt="SanskarJaiswal" />

-----
Credits: [Sanskarjaiswal2001](https://github.com/sanskarjaiswal2001)

Last Edited on: 20/06/2021
