
## Hi, I am Nikunj Sharma <img src="https://raw.githubusercontent.com/ABSphreak/ABSphreak/master/gifs/Hi.gif" width="30px"> it's nice to meet you|

I love  building Mobile Application using Flutter.

⚡ Fun Facts:
- 👯 I’m looking to collaborate on projects that are using Flutter.
- 🌱 I’m currently learning Flutter and Competative Programming.
- 📫 How to reach me: https://nouveau-riche.github.io/
- 😄 Pronouns: He/Him

 ### ⭐ GitHub Stats

 <p> 
    <img src="https://github-readme-stats.vercel.app/api?username=nouveau-riche&count_private=true&show_icons=true&theme=default&line" alt="Nikunj Stats" width="420"/> 
 </p>

### Let's Connect :coffee:
<p align="center">
	<a href="https://github.com/nouveau-riche"><img src="https://img.icons8.com/bubbles/50/000000/github.png" alt="GitHub"/></a>
	<a href="https://www.linkedin.com/in/nikunj-sharma-136182194/"><img src="https://img.icons8.com/bubbles/50/000000/linkedin.png" alt="LinkedIn"/></a>
	<a href="https://www.instagram.com/_nikunjjsharma/"><img src="https://img.icons8.com/bubbles/50/000000/instagram.png" alt="Instagram"/></a>
	<a href="https://twitter.com/Nikunjs07673277"><img src="https://img.icons8.com/bubbles/50/000000/twitter.png" alt="Twitter"/></a>
</p>

-----
Credits: [Nikunj Sharma](https://github.com/nouveau-riche)

Last Edited on: 25/11/2020